
import { AiFillLike } from "react-icons/ai";
import { FaCommentAlt, FaShare } from "react-icons/fa";
import type { PostType } from "../../../Types/Post.type";
import { Link } from 'react-router-dom';
import  axios from 'axios';
import { useQuery } from '@tanstack/react-query';
import Loader from '../../Loader/Loader';
import ComentCreation from "../../ComentCreation/ComentCreation";
import { HiDotsVertical } from "react-icons/hi";
import { MdEdit } from "react-icons/md";
import { RiDeleteBin6Line } from "react-icons/ri";
import { useContext, useState } from "react";
import { AuthContext } from "../../../Context/authContext";


export default function Post({ post }: { post: PostType }) {

const {body , image ,user ,createdAt ,topComment , _id} = post ;
const {name ,photo ,_id : userId} =user;
const {userId : loginUserId } = useContext(AuthContext);





function getPostComment(){
return axios.get (`https://route-posts.routemisr.com/posts/${_id}/comments?page=1&limit=10` , {
headers : {Authorization : `Bearer ${localStorage.getItem("userToken")}`}

})



}

 const [isOpen,setisOpen ] = useState(false)


const {
    data: postDetails,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ["GetPostDetails"],
    queryFn: getPostComment,

  });

  if (isLoading) {
    return <Loader />;
  }

  if (isError) {
    return <p>{error.message}</p>;
  }







  return (
    <div className="w-full max-w-[600px] mx-auto bg-slate-300 p-4 rounded-lg my-6">

      <div className="flex gap-4 justify-between items-center">
   <div className="flex gap-4 items-center">     <img
          src={photo}
          className="w-10 h-10 object-cover rounded-full border-2 border-white"
          alt={name}
        />

        <div>
          <p className="font-bold">{name}</p>
          <p className="text-sm text-slate-500">{createdAt}</p>
        </div>
        </div>
        <div className="relative">
{loginUserId == userId &&   <HiDotsVertical  onClick={ () => {setisOpen (!isOpen) }} className="font-bold text-2xl cursor-pointer" /> }

         
       {isOpen &&    <div className="bg-white p-2 rounded-lg absolute top-[120%] end-[-80px] shadow-2xl border-slate-400 border-2">
          <ul className="flex flex-col gap-3">
         <li className="flex gap-2 items-center cursor-pointer bg-slate-100 p-2">Edit<MdEdit />
         </li>
         <li className="flex gap-2 items-center cursor-pointer bg-slate-100 p-2">Delete <RiDeleteBin6Line /></li>

          </ul>

          </div>}
          </div>
        
      </div>

  
      <div className="p-4">
        <p className="mb-4">{body}</p>

        {image && (
          <img
            src={image}
            alt="Post"
            className="w-full rounded-lg"
          />
        )}
      </div>


      <div className="px-4 flex justify-between">
        <div className="font-bold flex gap-2 items-center">
          {post.likesCount} <AiFillLike /> Likes
        </div>
<Link to={`/postdetails/${_id}`}>
        <div className="font-bold flex gap-2 items-center">
          {post.commentsCount} <FaCommentAlt /> Comments
        </div>
        
        </Link>

        <div className="font-bold flex gap-2 items-center">
          {post.sharesCount} <FaShare /> Share
        </div>
      </div>


<ComentCreation postId={_id}  querykey={postDetails ?  ["getPostComment"]  : ["getAllPosts"]    }/>





{topComment &&
    <div className="my-2 p-4 rounded-sm bg-slate-100">
     <div className="flex gap-4 items-center my-2 p-2 bg-slate-100">
        <img
          src={topComment?.commentCreator.photo}
          className="w-10 h-10 object-cover rounded-full border-2 border-white"
          alt={name}
        />

        <div>
          <p className="font-bold">{topComment?.commentCreator.name
}</p>
          <p className="text-sm text-slate-500">{topComment?.createdAt}</p>
        </div>
      </div>

<p className="px-4">{topComment?.content}</p>
     </div> }


    </div>
  );
}
